#! /bin/sh
#
# postinst.sh
# Copyright (C) 2024 dongbin <dongbin0625@163.com>
#
# Distributed under terms of the MIT license.
#


cd /opt
./esvcpm
echo "esvcpm run"
